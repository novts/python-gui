from dearpygui import core, simple
from dearpygui.core import *
from dearpygui.simple import *

def save_callback(sender, data):
    print("Save Clicked")

set_main_window_size(400, 400)

with simple.window("Example Window", width=350, height=350, x_pos=20, y_pos=20):
    core.add_text("Hello world")
    core.add_button("Save", callback=save_callback)
    core.add_input_text("string")
    core.add_slider_float("float")

show_style_editor()
core.set_theme_item(mvGuiCol_WindowBg, 240, 240, 240, 255)
core.start_dearpygui()