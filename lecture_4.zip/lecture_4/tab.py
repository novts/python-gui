from fbs_runtime.application_context.PyQt5 import ApplicationContext
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *

import sys


if __name__ == '__main__':
    appctxt = ApplicationContext()       # 1. Instantiate ApplicationContext
    window = QTabWidget()
    window.setWindowTitle("Hello World!")
    window.resize(500, 200)

    tab1 = QWidget()
    tab2 = QWidget()

    window.addTab(tab1, "Tab 1")
    window.addTab(tab2, "Tab 2")

    layout1 = QFormLayout()
    layout2 = QFormLayout()

    label1 = QLabel()
    label1.setText("Hello PyQt5")
    line1 = QLineEdit()

    label2 = QLabel()
    label2.setText("Hello PyQt5")
    line2 = QLineEdit()

    layout1.addRow(label1)
    layout1.addRow(line1)

    layout2.addRow(label2)
    layout2.addRow(line2)

    tab1.setLayout(layout1)
    tab2.setLayout(layout2)

    window.show()
    exit_code = appctxt.app.exec_()      # 2. Invoke appctxt.app.exec_()
    sys.exit(exit_code)
