from fbs_runtime.application_context.PyQt5 import ApplicationContext
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *

import sys


if __name__ == '__main__':
    appctxt = ApplicationContext()       # 1. Instantiate ApplicationContext
    window = QMdiArea()
    window.tileSubWindows()
    #window.cascadeSubWindows()
    window.setWindowTitle("Hello World!")
    window.resize(500, 200)

    sub1 = QMdiSubWindow()
    sub1W = QWidget()
    sub1.setWidget(sub1W)

    sub2 = QMdiSubWindow()
    sub2W = QWidget()
    sub2.setWidget(sub2W)

    layout1 = QFormLayout()
    layout2 = QFormLayout()

    label1 = QLabel()
    label1.setText("Hello PyQt5")
    line1 = QLineEdit()

    label2 = QLabel()
    label2.setText("Hello PyQt5")
    line2 = QLineEdit()

    layout1.addRow(label1)
    layout1.addRow(line1)

    layout2.addRow(label2)
    layout2.addRow(line2)

    sub1W.setLayout(layout1)
    window.addSubWindow(sub1)
    sub2W.setLayout(layout2)
    window.addSubWindow(sub2)

    window.show()
    exit_code = appctxt.app.exec_()      # 2. Invoke appctxt.app.exec_()
    sys.exit(exit_code)
