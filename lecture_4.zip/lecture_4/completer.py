from fbs_runtime.application_context.PyQt5 import ApplicationContext
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *

import sys


if __name__ == '__main__':
    appctxt = ApplicationContext()       # 1. Instantiate ApplicationContext
    window = QWidget()
    window.setWindowTitle("Hello World!")
    window.resize(500, 300)

    layout = QVBoxLayout()

    words = QFile('words')
    words.open(QFile.ReadOnly | QFile.Text)
    data = QTextStream(words).readAll()
    list = data.split('\n');
    completer = QCompleter(list)
    completer.setCaseSensitivity(Qt.CaseInsensitive)
    completer.setModelSorting(QCompleter.UnsortedModel)
    completer.setFilterMode(Qt.MatchStartsWith)

    line = QLineEdit()
    line.setCompleter(completer)
    layout.addWidget(line)

    combo = QComboBox()
    combo.setEditable(True)
    combo.addItems(list)
    combo.setCompleter(completer)
    layout.addWidget(combo)

    window.setLayout(layout)
    window.show()
    exit_code = appctxt.app.exec_()      # 2. Invoke appctxt.app.exec_()
    sys.exit(exit_code)
