from fbs_runtime.application_context.PyQt5 import ApplicationContext
from PyQt5.QtWidgets import QWidget, QLabel, QHBoxLayout, QVBoxLayout, QGridLayout, QFormLayout, QPushButton, QLineEdit
from PyQt5.QtCore import Qt

import sys

if __name__ == '__main__':
    appctxt = ApplicationContext()       # 1. Instantiate ApplicationContext
    window = QWidget()
    window.setWindowTitle("Hello World!")
    window.resize(500, 300)
    #layout = QHBoxLayout()
    #layout = QVBoxLayout()
    #layout = QGridLayout()
    #layout.addWidget(QLabel('One'),0,0,1,2, Qt.AlignHCenter)
    #layout.addWidget(QLabel('Two'),1,0, Qt.AlignHCenter)
    #layout.addWidget(QLabel('Three'),1,1, Qt.AlignHCenter)
    layout = QFormLayout()
    layout.addRow(QPushButton("One"), QLineEdit());
    layout.addRow(QPushButton("Two"), QLineEdit());
    window.setLayout(layout)
    window.show()
    exit_code = appctxt.app.exec_()      # 2. Invoke appctxt.app.exec_()
    sys.exit(exit_code)
