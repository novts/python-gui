from fbs_runtime.application_context.PyQt5 import ApplicationContext
from PyQt5.QtWidgets import QWidget, QLabel, QLineEdit, QVBoxLayout, QPushButton, QComboBox, QCheckBox, QRadioButton, QTextEdit, QInputDialog, QMessageBox, QProgressBar, QSlider, QDateEdit
from PyQt5.QtGui import QIcon, QImage
from PyQt5.QtCore import Qt, QDate

import sys

def show():
    print(line.text())
    print(combo.currentText())
    print(check.text())
    print(check.checkState())
    print(check.isChecked())
    print(radio1.isChecked(), radio1.text())
    print(radio2.isChecked(), radio2.text())
    print(text.toPlainText())
    print(str(slider.value()))
    print(date.date().toPyDate())

def display():
    text , pressed = QInputDialog.getText(window, "Input Text", "Text: ",QLineEdit.Normal, "")
    intV, pressed = QInputDialog.getInt(window, "Input Integer","Number:", 10, 0, 100, 1)
    options = ("Option1", "Option2", "Option3")
    option, pressed = QInputDialog.getItem(window, "Select Item", "Option:", options, 0, False)
    decimal, pressed = QInputDialog.getDouble(window, "Input Decimal", "Value:",10.00, 0, 100, 2)
    if pressed:
        print(text)
        print(intV)
        print(option)
        print(decimal)


def show_popup():
    msg = QMessageBox()
    msg.setWindowTitle("Message Box")
    msg.setText("This is some random text")
    msg.setIcon(QMessageBox.Question)

    msg.setStandardButtons(QMessageBox.Cancel | QMessageBox.Ok)
    msg.setDefaultButton(QMessageBox.Ok)

    msg.setDetailedText("Extra details.....")
    msg.setInformativeText("This is some extra informative text")

    msg.buttonClicked.connect(popup)

    x = msg.exec_()

def popup(i):
    print(i.text())

def update():
    value = prog_bar.value()
    prog_bar.setValue(value + 1)

if __name__ == '__main__':
    appctxt = ApplicationContext()       # 1. Instantiate ApplicationContext
    im=QImage(appctxt.get_resource('images/im.jpg'))
    window = QWidget()
    window.setWindowTitle("Hello World!")
    window.resize(500, 300)

    layout = QVBoxLayout()

    label = QLabel()
    label.setText("Hello PyQt5")
    label.adjustSize()
    label.setAlignment(Qt.AlignHCenter)

    line = QLineEdit()
    line.setEchoMode(QLineEdit.Password)
    line.setFixedWidth(140)

    buttonS = QPushButton()
    buttonS.setText("Submit")
    buttonS.clicked.connect(show)

    buttonC = QPushButton()
    buttonC.setText("Clear")
    #buttonC.setIcon(QIcon('im.jpg'))
    buttonC.clicked.connect(line.clear)

    combo = QComboBox()
    combo.addItem("Python")
    combo.addItem("Java")
    combo.addItem("C++")
    combo.setFixedWidth(140)

    check = QCheckBox()
    check.setText("Option1")
    check.stateChanged.connect(show)

    radio1 = QRadioButton()
    radio1.setText("Option1")
    radio1.toggled.connect(show)
    layout.addWidget(radio1)

    radio2 = QRadioButton()
    radio2.setText("Option2")
    radio2.toggled.connect(show)
    layout.addWidget(radio2)

    text = QTextEdit()
    text.setPlaceholderText("Enter some text here")
    text.setUndoRedoEnabled(True)
    layout.addWidget(text)

    buttonD = QPushButton()
    buttonD.setText("Dialog")
    buttonD.clicked.connect(display)
    layout.addWidget(buttonD)

    buttonM = QPushButton()
    buttonM.setText("Message")
    buttonM.clicked.connect(show_popup)
    layout.addWidget(buttonM)

    prog_bar = QProgressBar()
    prog_bar.setGeometry(50, 50, 250, 30)
    prog_bar.setValue(0)
    layout.addWidget(prog_bar)
    buttonUp = QPushButton()
    buttonUp.setText("Update")
    buttonUp.clicked.connect(update)
    layout.addWidget(buttonUp)

    slider = QSlider(Qt.Horizontal)
    slider.setGeometry(50, 50, 200, 50)
    slider.setMinimum(0)
    slider.setMaximum(20)
    slider.setTickPosition(QSlider.TicksBelow)
    slider.setTickInterval(2)
    slider.valueChanged.connect(show)
    layout.addWidget(slider)

    date = QDateEdit()
    date.setMinimumDate(QDate(1900, 1, 1))
    date.setMaximumDate(QDate(2100, 12, 31))
    layout.addWidget(date)

    layout.addWidget(label)
    layout.addWidget(line)
    layout.addWidget(buttonS)
    layout.addWidget(buttonC)
    layout.addWidget(combo)
    layout.addWidget(check)

    window.setLayout(layout)
    window.show()
    exit_code = appctxt.app.exec_()      # 2. Invoke appctxt.app.exec_()
    sys.exit(exit_code)
