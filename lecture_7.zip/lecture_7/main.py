import kivy
from kivy.app import App
from kivy.uix.label import Label

# Defining a class
class MyFirstKivyApp(App):

    # Function that returns
    # the root widget
    def build(self):
        # Label with text Hello World is
        # returned as root widget
        #return Label(text="Hello World !")
        return Label(text="[color=ff3333][b]Label[/b] is Added [/color]\n[color=3333ff]Screen !!:):):):)[/color]",font_size='20sp', markup=True)
        #return Label(text='[color=ff3333]Hello[/color][color=3333ff]World[/color]',markup=True)
        # Here our class is initialized

# and its run() method is called.
# This initializes and starts
# our Kivy application.
MyFirstKivyApp().run()
