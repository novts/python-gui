import kivy
from kivy.app import App
from kivy.uix.checkbox import CheckBox
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label

# Defining a class
class KivyApp(App):
    # Function that returns
    # the root widget
    def build(self):
        layout = GridLayout()
        layout.cols=2
        layout.add_widget(Label(text='Male'))
        self.active = CheckBox(active=True)
        layout.add_widget(self.active)
        self.lbl_active = Label(text='Checkbox is on')
        layout.add_widget(self.lbl_active)
        self.active.bind(active=self.on_checkbox_Active)
        return layout

    def on_checkbox_Active(self, checkboxInstance, isActive):
        if isActive:
            self.lbl_active.text = "Checkbox is ON"
            print("Checkbox Checked")
        else:
            self.lbl_active.text = "Checkbox is OFF"
            print("Checkbox unchecked")

KivyApp().run()
