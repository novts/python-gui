from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.tabbedpanel import TabbedPanel
from kivy.uix.tabbedpanel import TabbedPanelHeader
from kivy.app import App

class TabbedPanelApp(App):
    def build(self):
        tp = TabbedPanel(do_default_tab=False)
        th1 = TabbedPanelHeader(text='Tab1')
        layout1=FloatLayout()
        layout1.add_widget(Label(text='Tab1'))
        th1.content=layout1
        tp.add_widget(th1)
        th2 = TabbedPanelHeader(text='Tab2')
        layout2 = FloatLayout()
        layout2.add_widget(Label(text='Tab2'))
        th2.content=layout2
        tp.add_widget(th2)
        return tp

if __name__ == '__main__':
    TabbedPanelApp().run()