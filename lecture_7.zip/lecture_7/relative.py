from kivy.uix.button import Button
from kivy.app import runTouchApp
from kivy.uix.relativelayout import RelativeLayout

layout = RelativeLayout()
btn1 = Button(text ='Hello world', size_hint =(.2, .2), pos =(300.0, 200.0))
btn2= Button(text ='Hello world!', size_hint =(.2, .2), pos =(-50.0, 200.0))
layout.add_widget(btn1)
layout.add_widget(btn2)
runTouchApp(layout)