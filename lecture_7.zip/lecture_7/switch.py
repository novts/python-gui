from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.switch import Switch
from kivy.app import runTouchApp


def switch_callback(switchObject, switchValue):
    # Switch value are True and False
    if (switchValue):
        print('Switch is ON:):):)')
    else:
        print('Switch is OFF:(:(:(')

switch=Switch(active = False)
layout = GridLayout(cols=2, padding=10)
layout.add_widget(Label(text ="Switch"))
layout.add_widget(switch)
switch.bind(active = switch_callback)

runTouchApp(layout)