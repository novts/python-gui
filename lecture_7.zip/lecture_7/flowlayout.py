from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.app import runTouchApp


layout = FloatLayout()
button1 = Button(text='Hello world',size_hint=(.5, .25), pos=(20, 20))
button2 = Button(text='Hello world', size_hint=(.6, .6), pos_hint={'x':.2, 'y':.2})
layout.add_widget(button1)
layout.add_widget(button2)
runTouchApp(layout)