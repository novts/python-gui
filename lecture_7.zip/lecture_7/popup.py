from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.config import Config
from kivy.app import runTouchApp


def onButtonPress(button):
    layout = GridLayout(cols=1, padding=10)
    popupLabel = Label(text="Click for pop-up")
    closeButton = Button(text="Close the pop-up")
    layout.add_widget(popupLabel)
    layout.add_widget(closeButton)
    # Instantiate the modal popup and display
    popup = Popup(title='Demo Popup',content=layout,auto_dismiss=False,size_hint=(None, None),size=(200, 200))
    popup.open()
    # Attach close button press with popup.dismiss action
    closeButton.bind(on_press=popup.dismiss)

Config.set('graphics', 'resizable', True)
layout = GridLayout(cols = 1, padding = 10)
button = Button(text="Click for pop-up")
layout.add_widget(button)

# Attach a callback for the button press event
button.bind(on_press=onButtonPress)

runTouchApp(layout)