from kivy.uix.button import Button
from kivy.app import runTouchApp
from kivy.uix.stacklayout import StackLayout

root = StackLayout(orientation ='tb-lr')
for i in range(25):
    btn = Button(text=str(i), size_hint =(.2, .1))
    root.add_widget(btn)
runTouchApp(root)