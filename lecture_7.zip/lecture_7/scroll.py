from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.core.window import Window
from kivy.app import runTouchApp

layout = GridLayout(cols=1, spacing=10, size_hint_y=None)
# Make sure the height is such that there is something to scroll.
layout.bind(minimum_height=layout.setter('height'))
Window.clearcolor = (1, 1, 1, 1)
Window.size = (200, 400)
for i in range(100):
    lbl = Label(text=str(i), size_hint_y=None, height=40, color=(1,0,1,1))
    layout.add_widget(lbl)
root = ScrollView(size_hint=(1, None), size=(Window.width, Window.height))
root.add_widget(layout)

runTouchApp(root)