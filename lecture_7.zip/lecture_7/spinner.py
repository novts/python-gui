from kivy.uix.spinner import Spinner
from kivy.uix.label import Label
from kivy.uix.floatlayout import FloatLayout
from kivy.app import runTouchApp


def on_spinner_select(spinner, text):
    label.text = "Selected: %s" % spinner.text
    print('The spinner', spinner, 'have text', text)

layout = FloatLayout()
spinner = Spinner(text ="Python",
              values =("Python", "Java", "C++", "C", "C#", "PHP"),
              background_color =(0.784, 0.443, 0.216, 1))
spinner.size_hint = (0.3, 0.2)
spinner.pos_hint = {'x': .35, 'y': .75}
layout.add_widget(spinner)
spinner.bind(text = on_spinner_select)
label = Label(text="Selected: %s" % spinner.text)
layout.add_widget(label)
label.pos_hint = {'x': .0, 'y': .3}

runTouchApp(layout)