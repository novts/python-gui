import kivy
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.scatter import Scatter
from kivy.uix.textinput import TextInput
from kivy.uix.boxlayout import BoxLayout

# Defining a class
class KivyApp(App):
    # Function that returns
    # the root widget
    def build(self):
        b = BoxLayout(orientation='vertical')
        # Adding the text input
        t = TextInput(font_size=50,
                      size_hint_y=None,
                      height=100)
        f = FloatLayout()
        # By this you are abel to move the
        # Text on the screen to anywhere you want
        s = Scatter()
        l = Label(text="Hello !", font_size=50)
        f.add_widget(s)
        s.add_widget(l)
        b.add_widget(t)
        b.add_widget(f)
        # Binding it with the label
        t.bind(text=l.setter('text'))
        return b
        # Here our class is initialized

# and its run() method is called.
# This initializes and starts
# our Kivy application.
KivyApp().run()
