from kivy.uix.progressbar import ProgressBar
from kivy.uix.boxlayout import BoxLayout
from kivy.clock import Clock
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.app import runTouchApp


def pop(instance):
    progress_bar.value = 1
    popup.open()

def next(dt):
    if progress_bar.value >= 100:
        return False
    progress_bar.value += 1

def puopen(instance):
    Clock.schedule_interval(next, 1 / 25)

layout=BoxLayout()
progress_bar = ProgressBar()
popup = Popup(title ='Download',content = progress_bar)
popup.bind(on_open = puopen)
layout.add_widget(Button(text ='Download', on_release = pop))

runTouchApp(layout)