from kivy.uix.floatlayout import FloatLayout
from kivy.uix.bubble import Bubble
from kivy.uix.button import Button
from kivy.app import App

class BubbleDemo(FloatLayout):

    def __init__(self, **kwargs):
        super(BubbleDemo, self).__init__(**kwargs)
        self.but = Button(text='Press to show bubble')
        self.but.bind(on_release=self.show_bubble)
        self.add_widget(self.but)

    def show_bubble(self, *l):
        self.bubb = bubb = Bubble(orientation = 'vertical',size_hint=(None, None),pos_hint={'center_x': .5, 'y': .6})
        bubb.add_widget(Button(text='Copy'))
        bubb.add_widget(Button(text='Paste'))
        self.add_widget(self.bubb)

class BubbleApp(App):
    def build(self):
        return BubbleDemo()

if __name__ == '__main__':
    BubbleApp().run()