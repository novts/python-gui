from kivy.uix.gridlayout import GridLayout
from kivy.uix.slider import Slider
from kivy.uix.label import Label
from kivy.properties  import NumericProperty
from kivy.app import runTouchApp

# Adding functionality behind the slider
# i.e when pressed increase the value
def on_value(instance,brightness):
    brightnessValue.text = "% d" % brightness

brightnessControl = Slider(min = 0, max = 100,orientation ='vertical',value_track = True,value_track_color =[1, 0, 0, 1])
layout = GridLayout(cols=4)
# 1st row - one label, one slider
layout.add_widget(Label(text='brightness'))
layout.add_widget(brightnessControl)

# 2nd row - one label for caption,
# one label for slider value
layout.add_widget(Label(text='Slider Value'))
brightnessValue = Label(text='0')
layout.add_widget(brightnessValue)

# On the slider object Attach a callback
# for the attribute named value
brightnessControl.bind(value=on_value)

runTouchApp(layout)