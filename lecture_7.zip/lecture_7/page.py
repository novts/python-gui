from kivy.uix.button import Button
from kivy.app import runTouchApp
from kivy.uix.pagelayout import PageLayout
from kivy.utils import get_color_from_hex

layout = PageLayout()
btn1 = Button(text='Page 1')
btn1.background_color = get_color_from_hex('#FF0000')
btn2 = Button(text='Page 2')
btn2.background_color = get_color_from_hex('#00FF00')
layout.add_widget(btn1)
layout.add_widget(btn2)
runTouchApp(layout)