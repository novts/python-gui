from kivy.animation import Animation
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.app import runTouchApp


def animate(instance):
    animation = Animation(pos=(100, 100), t='out_bounce')
    animation += Animation(pos=(200, 100), t='out_bounce')
    animation &= Animation(size=(500, 500))
    animation += Animation(size=(100, 50))
    animation.start(instance)

layout = FloatLayout()
button = Button(size_hint =(None, None), text ='Animate', on_press = animate)
layout.add_widget(button)
runTouchApp(layout)