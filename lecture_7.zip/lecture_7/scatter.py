from kivy.uix.floatlayout import FloatLayout
from kivy.uix.scatter import Scatter
from kivy.uix.label import Label
from kivy.app import App


class ScatterApp(App):
    def build(self):
        root = FloatLayout()
        scatter = Scatter()
        scatter.add_widget(Label(text='Scatter'))
        root.add_widget(scatter)
        return root

if __name__ == '__main__':
    ScatterApp().run()