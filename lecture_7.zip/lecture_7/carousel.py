from kivy.uix.image import AsyncImage
from kivy.uix.carousel import Carousel
from kivy.clock import Clock
from kivy.app import runTouchApp

root = Carousel(direction ='right', loop=True)
for i in range(10):
    src = "http://placehold.it/480x270.png&text=slide-%d&.png" %i
    # using Asynchronous image
    image = AsyncImage(source = src, allow_stretch = True)
    root.add_widget(image)

Clock.schedule_interval(root.load_next, 1)
runTouchApp(root)