import tkinter as tk
from tkinter import *

root = Tk()
var = StringVar()
label = Label( root, textvariable=var, relief=RAISED )
var.set("Hey!? How are you doing?")
label.pack()

whatever_you_do = "Whatever you do will be insignificant, but it is very important that you do it.\n(Mahatma Gandhi)"
msg = tk.Message(root, text = whatever_you_do)
msg.config(bg='lightgreen', font=('times', 24, 'italic'))
msg.pack()

def write_slogan():
    print("Tkinter is easy to use!")

frame = Frame(root)
frame.pack()
buttonQ = tk.Button(frame, text="QUIT", fg="red", command=quit)
buttonQ.pack(side=LEFT)
buttonT = Button(frame, text="Hello", command=write_slogan)
buttonT.pack(side=LEFT)

v = tk.IntVar()
v.set(1)

languages = [("Python", 101),("Perl", 102),("Java", 103),("C++", 104),("C", 105)]

def ShowChoice():
    print(v.get())

tk.Label(root, text="""Choose your favourite programming language:""", justify = tk.LEFT, padx = 20).pack()

for language, val in languages:
    tk.Radiobutton(root, text=language, padx = 20, variable=v, command=ShowChoice, value=val).pack(anchor=tk.W)

def print_states():
   print("male: %d,\nfemale: %d" % (var1.get(), var2.get()))

var1 = IntVar()
var2 = IntVar()
C1 = Checkbutton(root, text = "male", variable = var1, onvalue = 1, offvalue = 0, height=5, width = 20)
C2 = Checkbutton(root, text = "female", variable = var2, onvalue = 1, offvalue = 0, height=5, width = 20)
C1.pack()
C2.pack()
btn=Button(root, text='Show', command=print_states)
btn.pack()

root.mainloop()