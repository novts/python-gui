from tkinter import *
from math import *


def evaluate(event):
    res.configure(text="Result: " + str(eval(entry.get())))

w = Tk()
Label(w, text="Your Expression:").pack()
entry = Entry(w)
entry.bind("<Return>", evaluate)
entry.pack()
res = Label(w)
res.pack()

c = Canvas(w, width=200, height=100)
c.pack()

c.create_rectangle(50, 20, 150, 80, fill="#476042")
c.create_rectangle(65, 35, 135, 65, fill="yellow")
c.create_line(0, 0, 50, 20, fill="#476042", width=3)
c.create_line(0, 100, 50, 80, fill="#476042", width=3)
c.create_line(150,20, 200, 0, fill="#476042", width=3)
c.create_line(150, 80, 200, 100, fill="#476042", width=3)

def paint( event ):
   python_green = "#476042"
   x1, y1 = ( event.x - 1 ), ( event.y - 1 )
   x2, y2 = ( event.x + 1 ), ( event.y + 1 )
   c.create_oval( x1, y1, x2, y2, fill = python_green )

c.bind( "<B1-Motion>", paint )

#message = Label(w, text = "Press and Drag the mouse to draw" )
#message.pack( side = BOTTOM )

def show_values():
    print (sl1.get(), sl2.get())

sl1 = Scale(w, from_=0, to=42, tickinterval=8)
sl1.set(19)
sl1.pack()
sl2 = Scale(w, from_=0, to=200, length=600,tickinterval=10, orient=HORIZONTAL)
sl2.set(23)
sl2.pack()
Button(w, text='Show', command=show_values).pack()

S = Scrollbar(w)
T = Text(w, height=4, width=50)
S.pack(side=RIGHT, fill=Y)
T.pack(side=LEFT, fill=Y)
S.config(command=T.yview)
T.config(yscrollcommand=S.set)
T.tag_configure('big', font=('Verdana', 20, 'bold'))
quote = """HAMLET: To be, or not to be--that is the question:
Whether 'tis nobler in the mind to suffer
The slings and arrows of outrageous fortune
Or to take arms against a sea of troubles
And by opposing end them. To die, to sleep--
No more--and by a sleep to say we end
The heartache, and the thousand natural shocks
That flesh is heir to. 'Tis a consummation
Devoutly to be wished."""
T.insert(END, quote, 'big')

from tkinter import messagebox as mb
def answer():
    mb.showerror("Answer", "Sorry, no answer available")

def callback():
    if mb.askyesno('Verify', 'Really quit?'):
        mb.showwarning('Yes', 'Not yet implemented')
    else:
        mb.showinfo('No', 'Quit has been cancelled')

Button(text='Quit', command=callback).pack(fill=X)
Button(text='Answer', command=answer).pack(fill=X)

from tkinter import filedialog as fd
from tkinter.colorchooser import askcolor

def callback():
    name = fd.askopenfilename()
    print(name)
    result = askcolor(color="#6A9662", title="Bernd's Colour Chooser")
    print(result)

Button(text='File Open',command=callback).pack(fill=X)

def NewFile():
    print("New File!")
def OpenFile():
    name = fd.askopenfilename()
    print(name)
def About():
    print("This is a simple example of a menu")

menu = Menu(w)
w.config(menu=menu)
filemenu = Menu(menu)
menu.add_cascade(label="File", menu=filemenu)
filemenu.add_command(label="New", command=NewFile)
filemenu.add_command(label="Open", command=OpenFile)
filemenu.add_separator()
filemenu.add_command(label="Exit", command=quit)

helpmenu = Menu(menu)
menu.add_cascade(label="Help", menu=helpmenu)
helpmenu.add_command(label="About", command=About)

mb=  Menubutton (w, text="condiments", relief=RAISED )
mb.pack(fill=Y)
mb.menu =  Menu ( mb, tearoff = 0 )
mb["menu"] =  mb.menu

mayoVar = IntVar()
ketchVar = IntVar()

mb.menu.add_checkbutton ( label="mayo", variable=mayoVar )
mb.menu.add_checkbutton ( label="ketchup", variable=ketchVar )

w.mainloop()